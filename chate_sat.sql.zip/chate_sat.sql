-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 13, 2019 at 02:44 AM
-- Server version: 5.7.24-0ubuntu0.18.04.1
-- PHP Version: 7.2.10-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chate_sat`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1),
(9, '2019_12_12_103917_create_trip_data_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('051c9a0d3a2ec42167707337fdf8d0004657d81b6717acfa421f7636c4d6149c749f717be7d0256a', 1, 3, 'authToken', '[]', 0, '2019-12-12 02:02:10', '2019-12-12 02:02:10', '2020-12-12 08:32:10'),
('36ea3c494f3ce7deac70189837ed44f751c3d23c7bc478b6ee6dac04f6fc17ecd9d1ceed92329477', 5, 3, 'authToken', '[]', 0, '2019-12-12 02:17:36', '2019-12-12 02:17:36', '2020-12-12 08:47:36'),
('4f651373c9bf3414e8447b2215427098ce9865a8ab814e8dc813e4d1a2fcbfcccd49f3bc0714afdc', 4, 3, 'authToken', '[]', 0, '2019-12-12 02:17:17', '2019-12-12 02:17:17', '2020-12-12 08:47:17'),
('7e1a47886c2d0e94399014185c6bef2198923dba246bdd934a97d8383e92eb946c297148e34c36d0', 5, 3, 'authToken', '[]', 0, '2019-12-12 02:18:03', '2019-12-12 02:18:03', '2020-12-12 08:48:03'),
('b5a7d1595f7ebe9d4ef904cf2b5399a364648fb366748a02b9da5476616d871c2401e770065ea66a', 2, 3, 'authToken', '[]', 0, '2019-12-12 02:03:08', '2019-12-12 02:03:08', '2020-12-12 08:33:08'),
('ba183a7092b3b61185616aaef2ee37c2f57308396f2783f3ed0b781d1bb3daafc2d00a9e82e79367', 3, 3, 'authToken', '[]', 0, '2019-12-12 02:07:43', '2019-12-12 02:07:43', '2020-12-12 08:37:43'),
('cd619582462df13740f7e713e4c483789f304eed4e4239188b520875f2b3a9051e55bc282a655760', 5, 3, 'authToken', '[]', 0, '2019-12-12 02:19:49', '2019-12-12 02:19:49', '2020-12-12 08:49:49');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'ChateSat Personal Access Client', 'ytElw65pNCW33reRMLTEQwnKw4qPmJUolhbW1T5Y', 'http://localhost', 1, 0, 0, '2019-12-11 23:46:55', '2019-12-11 23:46:55'),
(2, NULL, 'ChateSat Password Grant Client', '5f4r8jhbXba0k1JPmmzaR9zLA0yDJtaA6Qvcsb60', 'http://localhost', 0, 1, 0, '2019-12-11 23:46:55', '2019-12-11 23:46:55'),
(3, NULL, 'Laravel Personal Access Client', 'zKzG98BgO6tIZg0V8uBlqMbKEM6s7wLiZQwiJBL7', 'http://localhost', 1, 0, 0, '2019-12-12 01:40:38', '2019-12-12 01:40:38'),
(4, NULL, 'Laravel Password Grant Client', '93GqYyDJwzLyXhFodRKnqrunLpEfEST3GpRKCpZA', 'http://localhost', 0, 1, 0, '2019-12-12 01:40:39', '2019-12-12 01:40:39');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2019-12-11 23:46:55', '2019-12-11 23:46:55'),
(2, 3, '2019-12-12 01:40:39', '2019-12-12 01:40:39');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trip_data`
--

CREATE TABLE `trip_data` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pack_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pack_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pack_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_credit` int(11) NOT NULL,
  `tag_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `validity_month` int(11) NOT NULL,
  `pack_price` double NOT NULL,
  `newbie_first_attend` tinyint(1) NOT NULL,
  `newbie_addition_credit` int(11) NOT NULL,
  `pack_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estimate_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trip_data`
--

INSERT INTO `trip_data` (`id`, `pack_name`, `pack_description`, `pack_type`, `total_credit`, `tag_name`, `validity_month`, `pack_price`, `newbie_first_attend`, `newbie_addition_credit`, `pack_alias`, `estimate_price`) VALUES
(1, 'Dr. Rossie Parisian', 'Occaecati odit ut quos eum in eos in.', 'sint', 4, 'Clair Welch', 8, 1817.607502876, 1, 7, 'Aut corporis aut doloremque animi architecto.', 6074.441622927),
(2, 'Aubree Schmitt', 'Consectetur dolorem qui debitis beatae optio similique molestias at.', 'aut', 5, 'Mr. Ulices Ziemann II', 5, 14890715.438394, 0, 9, 'Est ullam aut est at cum omnis quo.', 22.0963),
(3, 'Carson Bauch', 'Quam est delectus id atque molestiae ipsam.', 'fuga', 8, 'Ezequiel Lind II', 2, 10017335.35, 0, 0, 'Provident inventore ab facere labore aspernatur at.', 8567.102486),
(4, 'Mr. Demetrius Herman II', 'Tempora nam et praesentium.', 'quibusdam', 0, 'Virginia Hamill', 3, 34555, 0, 7, 'Perspiciatis nesciunt ex ea vitae.', 1530416.493),
(5, 'Mathew McCullough', 'Suscipit id molestiae doloremque non aperiam magni provident optio.', 'sit', 4, 'Miss Kylee Leffler', 3, 42596361.88824264, 1, 1, 'Est non dolor eveniet quo nobis ea debitis qui.', 2872.5688973),
(6, 'Rashad Kessler', 'Officiis voluptas recusandae illum consequatur possimus.', 'occaecati', 2, 'Jan Murazik', 8, 32178097.1, 1, 4, 'Consectetur et provident omnis libero.', 192958.79661389);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(4, 'first', 'first@gmail.com', NULL, '$2y$10$JzhhYOl2ryCROGxwF5iqD.Igne/Dn5XzOMoBfo99PgmwxpAwwxIO6', NULL, '2019-12-12 02:17:16', '2019-12-12 02:17:16'),
(5, 'second', 'second@gmail.com', NULL, '$2y$10$OimuT01UO5L.mE/d8k4C5uCFGrG7q8Ei.VVh8ncEw.HcBudT48aXO', NULL, '2019-12-12 02:17:36', '2019-12-12 02:17:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `trip_data`
--
ALTER TABLE `trip_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `trip_data`
--
ALTER TABLE `trip_data`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
